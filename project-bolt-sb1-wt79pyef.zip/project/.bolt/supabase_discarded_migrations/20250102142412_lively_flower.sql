/*
  # Correction de la fonction decrement_tokens

  1. Modifications
    - Amélioration de la fonction decrement_tokens pour gérer les erreurs
    - Ajout de vérifications supplémentaires
    - Retourne le nouveau nombre de tokens

  2. Sécurité
    - Maintien de la sécurité SECURITY DEFINER
    - Vérification de l'authentification
*/

CREATE OR REPLACE FUNCTION public.decrement_tokens()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_tokens INTEGER;
  updated_tokens INTEGER;
BEGIN
  -- Vérifier si l'utilisateur est authentifié
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Utilisateur non authentifié';
  END IF;

  -- Récupérer le nombre actuel de tokens
  SELECT tokens_remaining INTO current_tokens
  FROM public.users
  WHERE id = auth.uid();

  -- Vérifier si l'utilisateur existe
  IF current_tokens IS NULL THEN
    RAISE EXCEPTION 'Utilisateur non trouvé';
  END IF;

  -- Vérifier s'il reste des tokens
  IF current_tokens <= 0 THEN
    RETURN 0;
  END IF;

  -- Décrémenter les tokens
  UPDATE public.users
  SET tokens_remaining = tokens_remaining - 1
  WHERE id = auth.uid()
  RETURNING tokens_remaining INTO updated_tokens;

  RETURN updated_tokens;
END;
$$;