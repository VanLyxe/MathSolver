/*
  # Ajout de la politique d'insertion pour la table users

  1. Sécurité
    - Ajoute une politique permettant aux utilisateurs authentifiés d'insérer leurs propres données
*/

CREATE POLICY "Users can insert own data"
  ON public.users
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);