/*
  # Initial Schema Setup for Math Solver App

  1. New Tables
    - users
      - Custom user data including subscription and tokens
    - problems
      - Stores math problems and their solutions
  
  2. Security
    - RLS enabled on all tables
    - Policies for user-specific data access
*/

-- Users table extension
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id),
  email TEXT NOT NULL,
  tokens_remaining INTEGER DEFAULT 1,
  subscription_type TEXT DEFAULT 'free' CHECK (subscription_type IN ('free', 'premium')),
  subscription_end_date TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Problems table
CREATE TABLE IF NOT EXISTS public.problems (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users(id),
  problem_text TEXT NOT NULL,
  image_url TEXT,
  solution TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.problems ENABLE ROW LEVEL SECURITY;

-- Policies for users table
CREATE POLICY "Users can read own data"
  ON public.users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON public.users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Policies for problems table
CREATE POLICY "Users can CRUD own problems"
  ON public.problems
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);