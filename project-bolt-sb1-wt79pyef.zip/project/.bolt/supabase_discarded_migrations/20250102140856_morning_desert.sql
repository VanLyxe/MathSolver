/*
  # Création du bucket de stockage pour les images de problèmes

  1. Stockage
    - Crée un nouveau bucket pour stocker les images des problèmes de mathématiques
    - Configure les politiques de sécurité pour le bucket
*/

-- Création du bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('math-problems', 'math-problems', true);

-- Politique pour permettre l'upload d'images aux utilisateurs authentifiés
CREATE POLICY "Users can upload images"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'math-problems');

-- Politique pour permettre la lecture publique des images
CREATE POLICY "Anyone can view images"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'math-problems');