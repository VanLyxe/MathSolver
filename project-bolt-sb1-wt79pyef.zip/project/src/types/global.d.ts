interface Window {
  MathJax: {
    typesetClear: () => void;
    typesetPromise: () => Promise<void>;
  }
}