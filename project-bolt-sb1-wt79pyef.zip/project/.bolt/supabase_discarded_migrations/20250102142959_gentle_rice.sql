/*
  # Configuration du bucket de stockage

  1. Suppression et recréation du bucket
    - Supprime le bucket existant s'il existe
    - Crée un nouveau bucket public pour les images
  
  2. Politiques de sécurité
    - Permet aux utilisateurs authentifiés d'uploader des images
    - Permet à tout le monde de voir les images
*/

-- Suppression du bucket s'il existe
DROP POLICY IF EXISTS "Users can upload images" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can view images" ON storage.objects;

-- Suppression et recréation du bucket
DO $$
BEGIN
    DELETE FROM storage.buckets WHERE id = 'math-problems';
    INSERT INTO storage.buckets (id, name, public)
    VALUES ('math-problems', 'math-problems', true);
EXCEPTION
    WHEN others THEN NULL;
END $$;

-- Politiques pour le bucket
CREATE POLICY "Users can upload images"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
    bucket_id = 'math-problems' AND
    (LOWER(storage.extension(name)) = 'png' OR
     LOWER(storage.extension(name)) = 'jpg' OR
     LOWER(storage.extension(name)) = 'jpeg' OR
     LOWER(storage.extension(name)) = 'gif')
);

CREATE POLICY "Anyone can view images"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'math-problems');