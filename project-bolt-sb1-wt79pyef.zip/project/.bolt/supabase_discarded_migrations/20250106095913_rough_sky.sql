/*
  # Fix user creation policies

  1. Changes
    - Add policy to allow authenticated users to insert their own data
    - Add policy to allow authenticated users to update their own data
    - Add policy to allow authenticated users to read their own data
    
  2. Security
    - Maintain RLS but allow proper user creation and management
    - Ensure users can only access their own data
*/

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Users can read own data" ON public.users;
DROP POLICY IF EXISTS "Users can update own data" ON public.users;
DROP POLICY IF EXISTS "Users can insert own data" ON public.users;

-- Create comprehensive policies for users table
CREATE POLICY "Users can read own data"
  ON public.users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON public.users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own data"
  ON public.users
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Allow service role to manage users (needed for initial creation)
CREATE POLICY "Service role can manage users"
  ON public.users
  TO service_role
  USING (true)
  WITH CHECK (true);